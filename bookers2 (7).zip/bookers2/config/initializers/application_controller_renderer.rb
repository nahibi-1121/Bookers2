# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '4cea6df803163d3489a64452f10c0ad4a4295956720473ae49d1dcd19659a11c5e3d0824daec371fb6c44bf58fdfe5b0031dcd93830a9f2471d25ac2f3172f64'